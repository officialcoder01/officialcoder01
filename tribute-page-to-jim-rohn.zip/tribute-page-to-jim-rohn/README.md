# Tribute page to Jim Rohn 

A Pen created on CodePen.

Original URL: [https://codepen.io/ZION-MUSA/pen/ogNxJKw](https://codepen.io/ZION-MUSA/pen/ogNxJKw).

